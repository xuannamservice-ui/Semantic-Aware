#!/bin/bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "=========================================================="
echo " Starting 3DGS-OAM-FSO Scientific Experiments on $(hostname)"
echo " Date: $(date)"
echo " CPU Threads: $(nproc)"
echo "=========================================================="

mkdir -p ../data ../results

echo ""
echo ">>> [1/3] Running Experiment 1: Correlated Fading & Burst Erasures..."
python3 temporal_correlated_fading.py

echo ""
echo ">>> [2/3] Running Experiment 2: Hardware RIN & Insertion Loss Sweep..."
python3 hardware_rin_insertion_loss_sweep.py

echo ""
echo ">>> [3/3] Running Experiment 3: Dynamic Precision Adaptation..."
python3 dynamic_precision_relaxation.py

echo ""
echo "=========================================================="
echo " Packaging experimental data and source archive..."
cd ..
tar -czf results_and_source.tar.gz src/ data/
echo " Archive created at: $(pwd)/results_and_source.tar.gz"
echo " All experiments completed successfully!"
echo "=========================================================="
