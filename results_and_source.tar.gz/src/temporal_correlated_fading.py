"""
Experiment 1: Temporal Correlated Fading and Burst Erasure Simulation (Calibrated to Paper's Operating Point)
Addresses Limitation #2: Correlated Loss Traces and Burst Erasures in Turbulent FSO.
"""

import numpy as np
import json, os

np.random.seed(42)

def run_temporal_fading_experiment(n_slots=50000, tau_c_ms=2.5, T_slot_ms=1.0):
    print(f"[*] Running Calibrated Temporal Fading Simulation: {n_slots} slots, tau_c={tau_c_ms} ms...")
    
    # Inter-slot correlation under Taylor's frozen turbulence hypothesis
    # rho = exp(-(T_slot / tau_c)^(5/3))
    rho = np.exp(- (T_slot_ms / tau_c_ms)**(5.0/3.0))
    print(f"[*] Inter-slot correlation coefficient rho = {rho:.4f}")
    
    # Target operating point statistics from Section VII & Table XIV:
    # Marginal outage on mode +1: P_{out,+1} = 0.0248 (2.48%)
    # Marginal outage on mode -2: P_{out,-2} = 0.0252 (2.52%)
    # Joint outage on mode pair (-2, +1): pi_A = 2.0e-3 (0.20%)
    
    # We generate correlated bivariate Gauss-Markov series for modes -2 and +1
    # Channel power gains g_1(t) and g_2(t)
    # Temporal correlation rho, cross-modal correlation r_cross = 0.22 (from crosstalk matrix)
    
    # Stationary Gaussian process mapped through inverse CDF to target marginal outage thresholds
    z1 = np.zeros(n_slots)
    z2 = np.zeros(n_slots)
    
    # Initial states
    z1[0] = np.random.randn()
    z2[0] = 0.22 * z1[0] + np.sqrt(1 - 0.22**2) * np.random.randn()
    
    for t in range(1, n_slots):
        e1 = np.random.randn()
        e2 = 0.22 * e1 + np.sqrt(1 - 0.22**2) * np.random.randn()
        z1[t] = rho * z1[t-1] + np.sqrt(1 - rho**2) * e1
        z2[t] = rho * z2[t-1] + np.sqrt(1 - rho**2) * e2
        
    # Threshold corresponding to marginal outage 2.48% in standard normal:
    # Phi(thresh) = 0.0248  => thresh ≈ -1.963
    thresh1 = -1.963
    thresh2 = -1.956
    
    outage_mode_p1 = (z1 < thresh1)
    outage_mode_m2 = (z2 < thresh2)
    
    # Single anchor on mode +1 vs Replicated anchor pair (-2, +1)
    single_anchor_outage = outage_mode_p1
    dual_anchor_outage = outage_mode_p1 & outage_mode_m2
    
    p_out_single = float(np.mean(single_anchor_outage))
    p_out_dual = float(np.mean(dual_anchor_outage))
    
    # Burst length computation
    def compute_burst_stats(series):
        bursts = []
        cur = 0
        for x in series:
            if x:
                cur += 1
            else:
                if cur > 0:
                    bursts.append(cur)
                    cur = 0
        if cur > 0:
            bursts.append(cur)
        return bursts
        
    bursts_s = compute_burst_stats(single_anchor_outage)
    bursts_d = compute_burst_stats(dual_anchor_outage)
    
    # Count occurrences of bursts of length >= 1, 2, 3, 4, 5
    hist_s = {f"burst_len_ge_{l}": int(np.sum([b >= l for b in bursts_s])) for l in range(1, 6)}
    hist_d = {f"burst_len_ge_{l}": int(np.sum([b >= l for b in bursts_d])) for l in range(1, 6)}
    
    # Drift distortion simulation under burst erasures:
    # D_drift(L) = min(0.42, 0.12 * (1 + 0.45 * L))
    D_base = 0.12
    D_repeat_max = 0.42
    
    d_single = []
    d_dual = []
    cur_s, cur_d = 0, 0
    
    # Lyapunov Virtual Queue simulation under burst erasures:
    # delta_target = 1e-4
    delta_target = 1e-4
    Z_s, Z_d = 0.0, 0.0
    Z_trace_s, Z_trace_d = [], []
    
    for t in range(n_slots):
        # Single
        if single_anchor_outage[t]:
            cur_s += 1
            a_s = 1.0
        else:
            cur_s = 0
            a_s = 0.0
        d_single.append(min(D_repeat_max, D_base * (1.0 + 0.45 * cur_s)))
        Z_s = max(0.0, Z_s + a_s - delta_target)
        Z_trace_s.append(Z_s)
        
        # Dual
        if dual_anchor_outage[t]:
            cur_d += 1
            a_d = 1.0
        else:
            cur_d = 0
            a_d = 0.0
        d_dual.append(min(D_repeat_max, D_base * (1.0 + 0.45 * cur_d)))
        Z_d = max(0.0, Z_d + a_d - delta_target)
        Z_trace_d.append(Z_d)
        
    res = {
        "n_slots": n_slots,
        "tau_c_ms": tau_c_ms,
        "rho": float(rho),
        "P_out_single_anchor": p_out_single,
        "P_out_dual_anchor": p_out_dual,
        "gain_dual_vs_single": float(p_out_single / (p_out_dual + 1e-12)),
        "burst_counts_single": hist_s,
        "burst_counts_dual": hist_d,
        "mean_burst_len_single": float(np.mean(bursts_s)) if bursts_s else 0.0,
        "mean_burst_len_dual": float(np.mean(bursts_d)) if bursts_d else 0.0,
        "max_burst_len_single": int(np.max(bursts_s)) if bursts_s else 0,
        "max_burst_len_dual": int(np.max(bursts_d)) if bursts_d else 0,
        "mean_distortion_single": float(np.mean(d_single)),
        "mean_distortion_dual": float(np.mean(d_dual)),
        "distortion_reduction_pct": float((np.mean(d_single) - np.mean(d_dual)) / np.mean(d_single) * 100.0),
        "mean_Z_backlog_single": float(np.mean(Z_trace_s)),
        "mean_Z_backlog_dual": float(np.mean(Z_trace_d)),
        "virtual_queue_stabilized_dual": bool(np.mean(Z_trace_d) < 100.0)
    }
    
    print("\n[+] EXPERIMENT 1 RESULTS SUMMARY (CALIBRATED):")
    for k, v in res.items():
        print(f"    - {k:30s}: {v}")
        
    return res

if __name__ == "__main__":
    results = run_temporal_fading_experiment(n_slots=50000, tau_c_ms=2.5)
    os.makedirs("../data", exist_ok=True)
    with open("../data/exp1_temporal_correlated_results.json", "w") as f:
        json.dump(results, f, indent=4)
    print("\n[+] Saved Experiment 1 results to ../data/exp1_temporal_correlated_results.json")
